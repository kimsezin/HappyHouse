<template>
  <div class="map_wrap">
    <div id="map" :style="{ height: 950 + 'px', width: 100 + '%' }"></div>
    <div id="menu_wrap" class="bg_white">
      <div class="option">
        <div>현재 위치와 가까운 지역</div>
      </div>
      <hr />
      <ul id="placesList"></ul>
    </div>

    <a-modal v-model="modalVisible" title="Apt Information" @ok="handleOk">
      <div style="display: flex">
        <div>
          <a-descriptions :title="this.aptDetail.aptName" :column="1">
            <a-descriptions-item label="도로명주소">
              {{ this.aptDetail.dongName + " " + this.aptDetail.address }}
            </a-descriptions-item>
            <a-descriptions-item label="지번">
              {{ this.aptDetail.dongName + " " + this.aptDetail.jibun }}
            </a-descriptions-item>
            <a-descriptions-item label="건축년도">
              {{ this.aptDetail.buildYear }}
            </a-descriptions-item>
          </a-descriptions>
        </div>
        <div v-if="userInfo">
          <a-icon
            v-if="!isFillHeart"
            style="font-size: 24px"
            type="heart"
            theme="twoTone"
            twoToneColor="#eb2f96"
            @click="addInterest"
          />
          <svg
            v-if="isFillHeart"
            style="font-size: 24px; cursor: pointer"
            width="1em"
            height="1em"
            fill="#eb2f96"
            viewBox="0 0 1024 1024"
            @click="removeInterest"
          >
            <path
              d="M923 283.6c-13.4-31.1-32.6-58.9-56.9-82.8-24.3-23.8-52.5-42.4-84-55.5-32.5-13.5-66.9-20.3-102.4-20.3-49.3 0-97.4 13.5-139.2 39-10 6.1-19.5 12.8-28.5 20.1-9-7.3-18.5-14-28.5-20.1-41.8-25.5-89.9-39-139.2-39-35.5 0-69.9 6.8-102.4 20.3-31.4 13-59.7 31.7-84 55.5-24.4 23.9-43.5 51.7-56.9 82.8-13.9 32.3-21 66.6-21 101.9 0 33.3 6.8 68 20.3 103.3 11.3 29.5 27.5 60.1 48.2 91 32.8 48.9 77.9 99.9 133.9 151.6 92.8 85.7 184.7 144.9 188.6 147.3l23.7 15.2c10.5 6.7 24 6.7 34.5 0l23.7-15.2c3.9-2.5 95.7-61.6 188.6-147.3 56-51.7 101.1-102.7 133.9-151.6 20.7-30.9 37-61.5 48.2-91 13.5-35.3 20.3-70 20.3-103.3 0.1-35.3-7-69.6-20.9-101.9z"
            />
          </svg>
        </div>
      </div>
      <a-table :columns="columns" :data-source="dealList" :pagination="true"> </a-table>
    </a-modal>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import http from "@/api/http.js";

export default {
  name: "KakaoMap",
  data() {
    return {
      markers: [],
      infowindow: null,
      map: null,
      curLat: 0,
      curLng: 0,
      modalVisible: false,
      adjList: [],
      infoWindow: null,
      showAdjList: true,
      aptDetail: {},
      dealList: [],
      isFillHeart: 0,
      columns: [
        {
          title: "거래금액(만원)",
          dataIndex: "dealAmount",
        },
        {
          title: "거래일자",
          dataIndex: "dealDate",
        },
        {
          title: "면적",
          dataIndex: "area",
        },
        {
          title: "층",
          dataIndex: "floor",
          class: "text-muted",
        },
      ],
    };
  },
  created() {
    if (!("geolocation" in navigator)) {
      return;
    }

    // get position
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        this.curLat = pos.coords.latitude;
        this.curLng = pos.coords.longitude;

        if (window.kakao && window.kakao.maps) {
          this.initMap();
        } else {
          const script = document.createElement("script");
          /* global kakao */
          script.onload = () => kakao.maps.load(this.initMap);
          script.src =
            "//dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=1f1591a52d39027d8fb7a5e750d8bef6&libraries=services";
          document.head.appendChild(script);
        }
      },
      (err) => {
        alert(err.message);
      }
    );
  },
  computed: {
    ...mapState(["address", "aptList", "userInfo"]),
  },
  watch: {
    // address가 변하면 지도의 중심 좌표 이동시키기
    address: function () {
      // 주소-좌표 변환 객체를 생성
      if (this.address != "") {
        let geocoder = new kakao.maps.services.Geocoder();

        let moveMapPosition = (result, status) => {
          // 정상적으로 검색이 완료됐으면
          if (status === kakao.maps.services.Status.OK) {
            var coords = new kakao.maps.LatLng(result[0].y, result[0].x);
            console.log(this);

            // 지도의 중심을 결과값으로 받은 위치로 이동
            this.map.panTo(coords);
          }
        };
        // 주소로 좌표를 검색
        geocoder.addressSearch(this.address, moveMapPosition);
        this.setAddress("");
      }
    },

    aptList: function () {
      this.displayMarker([]);
      if (this.showAdjList) {
        document.getElementById("menu_wrap").remove();
        this.showAdjList = false;
      }
    },
  },
  methods: {
    ...mapActions(["panTo", "setAptList"]),

    // state address의 값 바꾸기
    setAddress(address) {
      this.panTo(address);
    },

    initMap() {
      const mapContainer = document.getElementById("map"), // 지도를 표시할 div
        mapOption = {
          center: new kakao.maps.LatLng(37.566797, 126.978669), // 지도의 중심좌표
          level: 7, // 지도의 확대 레벨
        };
      //지도 객체를 등록합니다.
      //지도 객체는 반응형 관리 대상이 아니므로 initMap에서 선언합니다.
      this.map = new kakao.maps.Map(mapContainer, mapOption);
      this.displayMarker([[this.curLat, this.curLng]]); // 접속 위치
      this.infoWindow = new kakao.maps.InfoWindow({ zIndex: 1 });

      http.get(`/map/address?lat=${this.curLat}&lng=${this.curLng}`).then((response) => {
        this.adjList = response.data;
        this.displayPlaces();
      });
    },

    // markerPositions에 위도,경도값에 마커 찍기
    displayMarker(markerPositions) {
      // 기존에 있던 마커 지우기
      if (this.markers.length > 0) {
        this.markers.forEach((marker) => marker.setMap(null));
      }

      if (markerPositions.length == 0) {
        for (let i = 0; i < this.aptList.length; i++) {
          markerPositions[i] = [this.aptList[i].lat, this.aptList[i].lng];
        }
      }

      const positions = markerPositions.map((position) => new kakao.maps.LatLng(...position));

      if (positions.length > 0) {
        this.markers = positions.map(
          (position) =>
            new kakao.maps.Marker({
              map: this.map,
              position,
            })
        );

        const bounds = positions.reduce(
          (bounds, latlng) => bounds.extend(latlng),
          new kakao.maps.LatLngBounds()
        );

        this.map.setBounds(bounds);

        //marker 클릭 시 이벤트 처리
        for (let index = 0; index < this.markers.length; index++) {
          kakao.maps.event.addListener(this.markers[index], "click", () => {
            if (this.adjList.length > 0) {
              this.modalVisible = true;

              this.aptDetail = this.aptList[index];

              this.getDealList(this.aptDetail.aptNo);

              if (this.userInfo) {
                http
                  .get(
                    `/house/interest?userId=${this.userInfo.userId}&aptNo=${this.aptDetail.aptNo}`
                  )
                  .then((response) => {
                    this.isFillHeart = response.data;
                  });
              }
            }
          });
        }
      }
    },

    // 접속위치와 가까운 지역 15개 마커로 표시하는 함수
    displayPlaces() {
      var listEl = document.getElementById("placesList"),
        menuEl = document.getElementById("menu_wrap"),
        fragment = document.createDocumentFragment(),
        bounds = new kakao.maps.LatLngBounds(),
        listStr = "";

      for (var i = 0; i < this.adjList.length; i++) {
        // 마커를 생성하고 지도에 표시합니다
        var placePosition = new kakao.maps.LatLng(this.adjList[i].lat, this.adjList[i].lng),
          marker = this.addMarker(placePosition, i),
          itemEl = this.getListItem(i, this.adjList[i]); // 검색 결과 항목 Element를 생성합니다

        // 검색된 장소 위치를 기준으로 지도 범위를 재설정하기위해
        // LatLngBounds 객체에 좌표를 추가합니다
        bounds.extend(placePosition);

        // 마커와 검색결과 항목에 mouseover 했을때
        // 해당 장소에 인포윈도우에 장소명을 표시합니다
        // mouseout 했을 때는 인포윈도우를 닫습니다

        ((marker, item) => {
          let title = item.gugunName + " " + item.dongName;

          kakao.maps.event.addListener(marker, "mouseover", () => {
            this.displayInfowindow(marker, title);
          });

          kakao.maps.event.addListener(marker, "mouseout", () => {
            this.infoWindow.close();
          });

          kakao.maps.event.addListener(marker, "click", () => {
            this.clickAdjMarker(item.dongCode);
          });

          itemEl.onmouseover = () => {
            this.displayInfowindow(marker, title);
          };

          itemEl.onmouseout = () => {
            this.infoWindow.close();
          };
        })(marker, this.adjList[i]);

        fragment.appendChild(itemEl);
      }

      // 검색결과 항목들을 검색결과 목록 Element에 추가합니다
      listEl.appendChild(fragment);
      menuEl.scrollTop = 0;

      // 검색된 장소 위치를 기준으로 지도 범위를 재설정합니다
      this.map.setBounds(bounds);
    },

    // 마커를 생성하고 지도 위에 마커를 표시하는 함수입니다
    addMarker(position, idx, title) {
      var imageSrc =
          "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_number_blue.png", // 마커 이미지 url, 스프라이트 이미지를 씁니다
        imageSize = new kakao.maps.Size(36, 37), // 마커 이미지의 크기
        imgOptions = {
          spriteSize: new kakao.maps.Size(36, 691), // 스프라이트 이미지의 크기
          spriteOrigin: new kakao.maps.Point(0, idx * 46 + 10), // 스프라이트 이미지 중 사용할 영역의 좌상단 좌표
          offset: new kakao.maps.Point(13, 37), // 마커 좌표에 일치시킬 이미지 내에서의 좌표
        },
        markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize, imgOptions),
        marker = new kakao.maps.Marker({
          position: position, // 마커의 위치
          image: markerImage,
        });

      marker.setMap(this.map); // 지도 위에 마커를 표출합니다
      this.markers.push(marker); // 배열에 생성된 마커를 추가합니다

      return marker;
    },

    // 접속 위치와 가까운 지역을 Element로 반환하는 함수입니다
    getListItem(index, places) {
      var el = document.createElement("li"),
        itemStr = `<span class="markerbg marker_${index + 1}"></span>
          <div class="info" style="padding: 10px 0 10px 55px;">
            <h5>${places.gugunName} ${places.dongName}</h5>
              <span class="distance" style="{ color:green; }">${places.distance}km</span>`;

      el.addEventListener("click", () => {
        this.clickAdjMarker(places.dongCode);
      });

      el.innerHTML = itemStr;
      el.className = "item";

      return el;
    },

    // 접속위치와 가까운 지역 목록 또는 마커를 클릭했을 때 호출되는 함수입니다
    // 인포윈도우에 장소명을 표시합니다
    displayInfowindow(marker, title) {
      var content = `<div style="padding:5px;z-index:1;width:150px;text-align:center;">${title}</div>`;

      this.infoWindow.setContent(content);
      this.infoWindow.open(this.map, marker);
    },

    async clickAdjMarker(dongCode) {
      await http.get(`/house/${dongCode}`).then((response) => {
        if (response.data.length != 0) {
          this.setAptList(response.data);
          this.infoWindow.close();
        } else {
          alert("선택하신 지역의 아파트 정보가 없습니다.");
        }
      });
    },

    handleOk(e) {
      this.modalVisible = false;
    },
    changeSize(size) {
      const container = document.getElementById("map");
      container.style.width = `${size}px`;
      container.style.height = `${size}px`;
      this.map.relayout();
    },

    async getDealList(aptNo) {
      await http.get(`/house/list/${aptNo}`).then((response) => {
        this.dealList = response.data;
        this.dealList.forEach((item) => {
          item.dealDate = `${item.dealYear}/${item.dealMonth}/${item.dealDay}`;
          item.key = item.no;
        });
      });
    },

    async addInterest() {
      await http
        .post(`/house/interest?userId=${this.userInfo.userId}&aptNo=${this.aptDetail.aptNo}`)
        .then((response) => {
          this.isFillHeart = response.data;
        });
    },

    async removeInterest() {
      await http
        .delete(`/house/interest?userId=${this.userInfo.userId}&aptNo=${this.aptDetail.aptNo}`)
        .then((response) => {
          this.isFillHeart = response.data == 1 ? 0 : 1;
        });
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
#map {
  width: 400px;
  height: 400px;
}

.button-group {
  margin: 10px 0px;
}

button {
  margin: 0 3px;
}

.map_wrap,
.map_wrap * {
  margin: 0;
  padding: 0;
  font-family: "Malgun Gothic", dotum, "돋움", sans-serif;
  font-size: 12px;
}
.map_wrap a,
.map_wrap a:hover,
.map_wrap a:active {
  color: #000;
  text-decoration: none;
}
/* .map_wrap {
  position: relative;
  width: 100%;
  height: 500px;
} */
#menu_wrap {
  position: absolute;
  top: 0;
  left: 20px;
  bottom: 0;
  width: 250px;
  /* height: 800px; */
  margin: 10px 0 30px 10px;
  padding: 5px;
  overflow-y: auto;
  background: rgba(255, 255, 255, 0.7);
  z-index: 1;
  font-size: 12px;
  border-radius: 10px;
}
.bg_white {
  background: #fff;
}
#menu_wrap hr {
  display: block;
  height: 1px;
  border: 0;
  border-top: 2px solid #5f5f5f;
  margin: 3px 0;
}
#menu_wrap .option {
  text-align: center;
}
#menu_wrap .option p {
  margin: 10px 0;
}
#menu_wrap .option button {
  margin-left: 5px;
}
#placesList li {
  list-style: none;
}
#placesList .item {
  position: relative;
  border-bottom: 1px solid #888;
  overflow: hidden;
  cursor: pointer;
  min-height: 65px;
}
#placesList > .item span {
  display: block;
  margin-top: 4px;
}
#placesList .item h5,
#placesList .item .info {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
#placesList .item .info {
  padding: 10px 0 10px 55px;
}
#placesList .info .gray {
  color: #8a8a8a;
}
#placesList .info .jibun {
  padding-left: 26px;
  background: url(https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/places_jibun.png)
    no-repeat;
}
#placesList .info .distance {
  color: #009900;
}
#placesList .item .markerbg {
  float: left;
  position: absolute;
  width: 36px;
  height: 37px;
  margin: 10px 0 0 10px;
  background: url(https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_number_blue.png)
    no-repeat;
}
#placesList .item .marker_1 {
  background-position: 0 -10px;
}
#placesList .item .marker_2 {
  background-position: 0 -56px;
}
#placesList .item .marker_3 {
  background-position: 0 -102px;
}
#placesList .item .marker_4 {
  background-position: 0 -148px;
}
#placesList .item .marker_5 {
  background-position: 0 -194px;
}
#placesList .item .marker_6 {
  background-position: 0 -240px;
}
#placesList .item .marker_7 {
  background-position: 0 -286px;
}
#placesList .item .marker_8 {
  background-position: 0 -332px;
}
#placesList .item .marker_9 {
  background-position: 0 -378px;
}
#placesList .item .marker_10 {
  background-position: 0 -423px;
}
#placesList .item .marker_11 {
  background-position: 0 -470px;
}
#placesList .item .marker_12 {
  background-position: 0 -516px;
}
#placesList .item .marker_13 {
  background-position: 0 -562px;
}
#placesList .item .marker_14 {
  background-position: 0 -608px;
}
#placesList .item .marker_15 {
  background-position: 0 -654px;
}
#pagination {
  margin: 10px auto;
  text-align: center;
}
#pagination a {
  display: inline-block;
  margin-right: 10px;
}
#pagination .on {
  font-weight: bold;
  cursor: default;
  color: #777;
}
</style>
