<template>
  <!-- Profile Information Card -->
  <a-card
    :bordered="false"
    class="header-solid h-full card-profile-information"
    :bodyStyle="{ paddingTop: 0, paddingBottom: '16px' }"
    :headStyle="{ paddingRight: 0 }"
  >
    <template #title>
      <h6 class="font-semibold m-0">Profile Information</h6>
    </template>
    <div v-if="visible">
      <label v-if="visible">{{ this.userInfo.description }}</label>
      <p class="text-dark"></p>
      <hr class="my-25" />
      <a-descriptions :title="this.userInfo.userId" :column="1">
        <a-descriptions-item label="Mobile"> (+82) {{ this.userInfo.phone }} </a-descriptions-item>
        <a-descriptions-item label="Email"> {{ this.userInfo.email }} </a-descriptions-item>
        <a-descriptions-item label="Location">
          {{ this.userInfo.address }}
        </a-descriptions-item>
      </a-descriptions>
    </div>
    <div v-else>
      <a-input :placeholder="this.userInfo.description" v-model="newUserInfo.description"></a-input>
      <p class="text-dark"></p>
      <hr class="my-25" />
      <a-descriptions :title="this.userInfo.userId" :column="1">
        <a-descriptions-item label="Mobile"
          ><a-input :placeholder="this.userInfo.phone" v-model="newUserInfo.phone"></a-input
        ></a-descriptions-item>
        <a-descriptions-item label="Email"
          ><a-input :placeholder="this.userInfo.email" v-model="newUserInfo.email"></a-input
        ></a-descriptions-item>
        <a-descriptions-item label="Location"
          ><a-input :placeholder="this.userInfo.address" v-model="newUserInfo.address"></a-input
        ></a-descriptions-item>
      </a-descriptions>
      <a-button @click="editDescription()">수정</a-button>
    </div>

    <a-button type="link" slot="extra" @click="updateDescription()">
      <svg
        width="20"
        height="20"
        viewBox="0 0 20 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          class="fill-muted"
          d="M13.5858 3.58579C14.3668 2.80474 15.6332 2.80474 16.4142 3.58579C17.1953 4.36683 17.1953 5.63316 16.4142 6.41421L15.6213 7.20711L12.7929 4.37868L13.5858 3.58579Z"
          fill="#111827"
        />
        <path
          class="fill-muted"
          d="M11.3787 5.79289L3 14.1716V17H5.82842L14.2071 8.62132L11.3787 5.79289Z"
          fill="#111827"
        />
      </svg>
    </a-button>
  </a-card>
  <!-- / Profile Information Card -->
</template>

<script>
import { mapActions, mapState } from "vuex";
import http from "@/api/http.js";
export default {
  data() {
    return {
      visible: true,
      newUserInfo: {
        description: "",
        phone: "",
        email: "",
        address: "",
      },
    };
  },
  computed: {
    ...mapState(["userInfo", "isLogin"]), //로그인 여부 확인하기
  },
  methods: {
    ...mapActions(["getUserInfo", "setUserInfo"]),
    updateDescription() {
      this.visible = !this.visible;
    },
    async editDescription() {
      await http
        .post(
          `/user/desc?description=${this.newUserInfo.description}&userId=${this.userInfo.userId}&phone=${this.newUserInfo.phone}&address=${this.newUserInfo.address}&email=${this.newUserInfo.email}`
        )
        .then(() => {})
        .catch((error) => {
          console.log(error);
        });
      alert("Update your userInfo");

      this.newUserInfo.userId = this.userInfo.userId;
      this.newUserInfo.password = this.userInfo.password;
      this.newUserInfo.userName = this.userInfo.userName;
      this.setUserInfo(this.newUserInfo);

      this.$router.go("/Profile");
    },
  },
};
</script>
