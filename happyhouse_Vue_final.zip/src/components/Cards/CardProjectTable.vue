<template>
  <!-- Projects Table Card -->
  <a-card
    :bordered="false"
    class="header-solid h-full"
    :bodyStyle="{ padding: 10 }"
  >
    <template #title>
      <a-row type="flex" align="middle">
        <a-col :span="24" :md="12">
          <h6>Infra Information</h6>
          <!-- <p>done this month <span class="text-primary">+40%</span></p> -->
        </a-col>
        <a-col
          :span="24"
          :md="11"
          style="display: flex; align-items: center; justify-content: flex-end"
        >
          <a-radio-group v-model="projectHeaderBtns" size="small">
            <!-- <a-radio-button value="all">ALL</a-radio-button> -->
            <a-radio-button value="store">STORES</a-radio-button>
            <a-radio-button value="school">SCHOOLS</a-radio-button>
          </a-radio-group>
        </a-col>
      </a-row>
    </template>
    <a-table :columns="columns" :data-source="data" :pagination="true">
      <template slot="moveBtn" slot-scope="row">
        <a-button
          style="width: 30px"
          type="link"
          :data-id="row.key"
          @click="moveInfra(row.key)"
        >
          <svg
            viewBox="64 64 896 896"
            data-icon="select"
            width="1em"
            height="1em"
            fill="#8C8C9B"
            aria-hidden="true"
            focusable="false"
            class=""
          >
            <path
              d="M880 112H144c-17.7 0-32 14.3-32 32v736c0 17.7 14.3 32 32 32h360c4.4 0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8H184V184h656v320c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8V144c0-17.7-14.3-32-32-32zM653.3 599.4l52.2-52.2a8.01 8.01 0 0 0-4.7-13.6l-179.4-21c-5.1-.6-9.5 3.7-8.9 8.9l21 179.4c.8 6.6 8.9 9.4 13.6 4.7l52.4-52.4 256.2 256.2c3.1 3.1 8.2 3.1 11.3 0l42.4-42.4c3.1-3.1 3.1-8.2 0-11.3L653.3 599.4z"
            ></path>
          </svg>
        </a-button>
      </template>
    </a-table>
  </a-card>
  <!-- / Projects Table Card -->
</template>

<script>
import { mapActions } from "vuex";

export default {
  props: {
    data: {
      type: Array,
      default: () => [],
    },
    columns: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      // Active button for the "Projects" table's card header radio button group.
      projectHeaderBtns: "store",
    };
  },
  methods: {
    ...mapActions(["setMoveStoreNo", "setMoveSchoolId", "setInfraOption"]),
    moveInfra(key) {
      if (this.projectHeaderBtns == "store") {
        this.setMoveStoreNo(key);
      } else {
        this.setMoveSchoolId(key);
      }
    },
  },
  watch: {
    projectHeaderBtns: function () {
      this.setInfraOption(this.projectHeaderBtns);
    },
  },
};
</script>
