<template>
  <!-- Billing Information Card -->
  <a-card
    :bordered="false"
    class="header-solid h-full"
    :bodyStyle="{ height: 1000 + 'px', paddingTop: 0, paddingBottom: '16px' }"
  >
    <template #title>
      <a-row>
        <span class="font-semibold m-0">QnA</span>

        <a-select
          default-value="userId"
          style="width: 15%; margin-left: 10%"
          @change="handleChange"
        >
          <a-select-option value="userId"> ID </a-select-option>
          <a-select-option value="subject"> Subject </a-select-option>
          <a-select-option value="content"> Content </a-select-option>
        </a-select>
        <a-input-search
          class="header-search"
          placeholder="Type here…"
          @search="onSearch"
          style="width: 40%; margin-left: 2%"
        >
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M8 4C5.79086 4 4 5.79086 4 8C4 10.2091 5.79086 12 8 12C10.2091 12 12 10.2091 12 8C12 5.79086 10.2091 4 8 4ZM2 8C2 4.68629 4.68629 2 8 2C11.3137 2 14 4.68629 14 8C14 9.29583 13.5892 10.4957 12.8907 11.4765L17.7071 16.2929C18.0976 16.6834 18.0976 17.3166 17.7071 17.7071C17.3166 18.0976 16.6834 18.0976 16.2929 17.7071L11.4765 12.8907C10.4957 13.5892 9.29583 14 8 14C4.68629 14 2 11.3137 2 8Z"
            fill="#111827"
          />
        </a-input-search>
        <a-button type="primary" @click="showModal" style="float: right">
          <span class="font-semibold m-0"><a-icon type="form" theme="outlined" />REGISTER</span>
        </a-button>
        <a-modal v-model="visible" title="Register QnA" @ok="handleOk">
          <div class="col-info">
            Subject :
            <a-input placeholder="Subject" v-model="article.subject" />
            Content :
            <a-input placeholder="Content" v-model="article.content" />
          </div>
        </a-modal>
      </a-row>
    </template>

    <a-row :gutter="[24, 24]">
      <a-col :span="24" v-for="(article, index) in articles" :key="article.articleNo">
        <a-card
          style="cursor: pointer"
          :bordered="false"
          class="card-billing-info"
          v-if="!edit[index]"
        >
          <div class="col-info" @click="clickBoard(article.articleNo)">
            <a-descriptions :title="article.subject" :column="1">
              <a-descriptions-item label="Writer">
                {{ article.userId }}
              </a-descriptions-item>
              <a-descriptions-item label="">
                {{ article.regtime }}
              </a-descriptions-item>
              <a-descriptions-item label="">
                {{ article.content }}
              </a-descriptions-item>
            </a-descriptions>
          </div>

          <div
            class="col-action"
            v-if="article.userId === userInfo.userId || userInfo.userId === 'admin'"
          >
            <a-button type="link" size="small" @click="deleteArticle(article.articleNo)">
              <svg
                width="16"
                height="16"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  class="fill-danger"
                  d="M9 2C8.62123 2 8.27497 2.214 8.10557 2.55279L7.38197 4H4C3.44772 4 3 4.44772 3 5C3 5.55228 3.44772 6 4 6L4 16C4 17.1046 4.89543 18 6 18H14C15.1046 18 16 17.1046 16 16V6C16.5523 6 17 5.55228 17 5C17 4.44772 16.5523 4 16 4H12.618L11.8944 2.55279C11.725 2.214 11.3788 2 11 2H9ZM7 8C7 7.44772 7.44772 7 8 7C8.55228 7 9 7.44772 9 8V14C9 14.5523 8.55228 15 8 15C7.44772 15 7 14.5523 7 14V8ZM12 7C11.4477 7 11 7.44772 11 8V14C11 14.5523 11.4477 15 12 15C12.5523 15 13 14.5523 13 14V8C13 7.44772 12.5523 7 12 7Z"
                  fill="#111827"
                />
              </svg>
              <span class="text-danger">DELETE</span>
            </a-button>

            <a-button type="link" size="small" @click="editArticle(index)">
              <svg
                width="16"
                height="16"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  class="fill-muted"
                  d="M13.5858 3.58579C14.3668 2.80474 15.6332 2.80474 16.4142 3.58579C17.1953 4.36683 17.1953 5.63316 16.4142 6.41421L15.6213 7.20711L12.7929 4.37868L13.5858 3.58579Z"
                  fill="#111827"
                />
                <path
                  class="fill-muted"
                  d="M11.3787 5.79289L3 14.1716V17H5.82842L14.2071 8.62132L11.3787 5.79289Z"
                  fill="#111827"
                />
              </svg>
              <span class="text-dark">EDIT</span>
            </a-button>
          </div>
        </a-card>
        <!-- 여기 바꿈 -->
        <a-card :bordered="false" class="card-billing-info" v-if="edit[index]">
          <div class="col-info">
            NewSubject :
            <a-input :placeholder="article.subject" v-model="articles[index].subject" />
            NewContent :
            <a-input :placeholder="article.content" v-model="articles[index].content" />

            <a-button @click="updateArticle(article.articleNo, index)"> EDIT </a-button>
          </div>
        </a-card>
      </a-col>
    </a-row>
    <a-pagination
      v-if="!search"
      v-model="currentPage"
      :total="this.totalArticleCnt * 2"
      show-less-items
    />
    <a-pagination
      v-else
      v-model="searchCurrentPage"
      :total="this.totalSearchArticleCnt * 2"
      show-less-items
    />
  </a-card>
  <!-- / Billing Information Card -->
</template>

<script>
import { mapState, mapActions } from "vuex";
import axios from "@/api/http.js";

export default {
  data() {
    return {
      articles: [],
      edit: [],
      visible: false,
      article: {
        subject: "",
        content: "",
      },
      key: "userId",
      currentPage: 1,
      searchCurrentPage: 1,
      totalArticleCnt: 0,
      totalSearchArticleCnt: 0,
      search: false,
      word: "",
    };
  },
  mounted() {
    this.getArticles();
    this.getArticlesCnt();
  },
  computed: {
    ...mapState(["userInfo"]), //로그인 여부 확인하기
  },
  watch: {
    currentPage: function () {
      this.getArticles();
    },
    searchCurrentPage: function () {
      this.onSearch(this.word);
    },
  },
  methods: {
    ...mapActions(["setClickBoard", "setClickBoardNo"]),
    getArticlesCnt() {
      axios.get(`/board/count`).then(({ data }) => {
        this.totalArticleCnt = data;
      });
    },

    getArticles() {
      axios.get(`/board/pagination/${(this.currentPage - 1) * 5}`).then(({ data }) => {
        this.articles = data;
      });
    },

    deleteArticle(articleNo) {
      axios.delete(`/board/${articleNo}`).then(() => {
        this.$router.go("/QnA");
      });
    },

    editArticle(index) {
      this.$set(this.edit, index, !this.edit[index]);
    },

    updateArticle(articleNo, index) {
      console.log("in updateArticle");
      axios
        .put(`/board/${articleNo}`, {
          articleNo: articleNo,
          userId: this.articles[index].userId,
          subject: this.articles[index].subject,
          content: this.articles[index].content,
          hit: this.articles[index].hit,
        })
        .then(() => {
          this.editArticle(index);
        });
    },

    showModal() {
      this.visible = true;
    },

    handleOk(e) {
      if (this.article.subject != "" && this.article.content != "") {
        axios
          .post(`/board`, {
            userId: this.userInfo.userId,
            subject: this.article.subject,
            content: this.article.content,
          })
          .then(() => {
            this.article.subject = "";
            this.article.content = "";
            this.getArticles();
            this.edit.push(false);
          });
        this.visible = false;
        this.$router.go("/QnA");
      } else {
        alert("제목과 내용을 입력해주세요.");
      }
    },

    handleChange(value) {
      console.log(`selected ${value}`);
      this.key = value;
    },

    async onSearch(word) {
      if (word != "") {
        this.word = word;
        this.search = true;
        // this.searchCurrentPage = 1;
        await axios
          .get(
            `/board/list/${this.key}?word=${this.word}&currentPage=${
              (this.searchCurrentPage - 1) * 5
            }`
          )
          .then(({ data }) => {
            this.articles = data;
          });
        axios.get(`/board/search/count?word=${this.word}&key=${this.key}`).then(({ data }) => {
          console.log("1: " + data);
          this.totalSearchArticleCnt = data;
        });
      } else {
        alert("검색할 키워드를 입력해주세요.");
      }
    },

    clickBoard(articleNo) {
      console.log(articleNo);
      this.setClickBoard(true);
      this.setClickBoardNo(articleNo);
    },
  },
};
</script>
