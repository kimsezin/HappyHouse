<template>
  <!-- Your Transactions Card -->
  <a-card
    :bordered="false"
    class="header-solid h-full"
    :bodyStyle="{ paddingTop: 0, paddingBottom: '16px' }"
  >
    <template #title>
      <h6 class="font-semibold m-0">Comment</h6>
    </template>
    <p slot="extra" class="card-header-date"></p>
    <a-row :gutter="[24, 24]">
      <a-col :span="24" v-for="(comment, index) in commentList" :key="comment.commentNo">
        <a-card v-if="!edit[index]" :bordered="false" class="card-billing-info">
          <div class="col-info">
            <a-descriptions :title="comment.content" :column="1">
              <a-descriptions-item label="Writer">
                {{ comment.userId }}
              </a-descriptions-item>
              <a-descriptions-item label="">
                {{ comment.regtime }}
              </a-descriptions-item>
            </a-descriptions>
          </div>

          <div
            class="col-action"
            v-if="comment.userId === userInfo.userId || userInfo.userId === 'admin'"
          >
            <a-button @click="deleteComment(comment.commentNo)" type="link" size="small">
              <svg
                width="16"
                height="16"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  class="fill-danger"
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M9 2C8.62123 2 8.27497 2.214 8.10557 2.55279L7.38197 4H4C3.44772 4 3 4.44772 3 5C3 5.55228 3.44772 6 4 6L4 16C4 17.1046 4.89543 18 6 18H14C15.1046 18 16 17.1046 16 16V6C16.5523 6 17 5.55228 17 5C17 4.44772 16.5523 4 16 4H12.618L11.8944 2.55279C11.725 2.214 11.3788 2 11 2H9ZM7 8C7 7.44772 7.44772 7 8 7C8.55228 7 9 7.44772 9 8V14C9 14.5523 8.55228 15 8 15C7.44772 15 7 14.5523 7 14V8ZM12 7C11.4477 7 11 7.44772 11 8V14C11 14.5523 11.4477 15 12 15C12.5523 15 13 14.5523 13 14V8C13 7.44772 12.5523 7 12 7Z"
                  fill="#111827"
                />
              </svg>
              <a><span class="text-danger">DELETE</span></a>
            </a-button>
            <a-button @click="editComment(index)" type="link" size="small">
              <svg
                width="16"
                height="16"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  class="fill-muted"
                  d="M13.5858 3.58579C14.3668 2.80474 15.6332 2.80474 16.4142 3.58579C17.1953 4.36683 17.1953 5.63316 16.4142 6.41421L15.6213 7.20711L12.7929 4.37868L13.5858 3.58579Z"
                  fill="#111827"
                />
                <path
                  class="fill-muted"
                  d="M11.3787 5.79289L3 14.1716V17H5.82842L14.2071 8.62132L11.3787 5.79289Z"
                  fill="#111827"
                />
              </svg>
              <span class="text-dark">EDIT</span>
            </a-button>
          </div>
        </a-card>
        <a-card :bordered="false" class="card-billing-info" v-if="edit[index]">
          <div class="col-info">
            NewContent :
            <a-input :placeholder="comment.content" v-model="commentList[index].content" />
            <a-button @click="updateComment(comment.commentNo, index)"> EDIT </a-button>
          </div>
        </a-card>
      </a-col>
      <div style="width: 97%">
        <a-textarea
          v-model="newCommentContent"
          style="margin: 10px"
          rows="4"
          placeholder="Type Comment..."
        />
        <a-button @click="registComment" type="primary" style="float: right">
          <span class="font-semibold m-0"><a-icon type="form" theme="outlined" />OK</span>
        </a-button>
      </div>
    </a-row>
  </a-card>

  <!-- / Your Transactions Card -->
</template>

<script>
import { mapState, mapActions } from "vuex";
import http from "@/api/http.js";
import axios from "axios";

export default {
  data() {
    return {
      edit: [],
      commentList: [],
      newCommentContent: "",
    };
  },
  computed: {
    ...mapState(["clickBoardNo", "userInfo"]),
  },
  mounted() {
    this.setClickBoardNo(0);
  },
  watch: {
    clickBoardNo: function () {
      console.log("찍히나요");
      http.get(`/comment/${this.clickBoardNo}`).then((response) => {
        this.commentList = response.data;
      });
    },
  },
  methods: {
    ...mapActions(["setClickBoardNo"]),
    registComment() {
      http
        .post(
          `/comment?articleNo=${this.clickBoardNo}&userId=${this.userInfo.userId}&content=${this.newCommentContent}`
        )
        .then((response) => {
          http.get(`/comment/${this.clickBoardNo}`).then((response) => {
            this.commentList = response.data;
          });
        });
      this.newCommentContent = "";
    },
    deleteComment(commentNo) {
      http.delete(`/comment/${commentNo}`).then((response) => {
        http.get(`/comment/${this.clickBoardNo}`).then((response) => {
          this.commentList = response.data;
        });
      });
    },
    editComment(index) {
      this.$set(this.edit, index, !this.edit[index]);
    },
    updateComment(commentNo, index) {
      http
        .put(`/comment?commentNo=${commentNo}&content=${this.commentList[index].content}`)
        .then(() => {
          this.editComment(index);
        });
    },
  },
};
</script>
