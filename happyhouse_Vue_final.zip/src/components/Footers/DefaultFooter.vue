<template>
  <!-- Layout Footer -->
  <a-layout-footer>
    <!-- Footer Navigation Menu -->
    <a-menu mode="horizontal">
      <a-menu-item><a href="https://www.naver.com">Git</a></a-menu-item>
      <a-menu-item
        ><a href="https://www.instagram.com/se__zin">About Us</a></a-menu-item
      >
      <a-menu-item><a href="https://ant.design/">License</a></a-menu-item>
    </a-menu>
    <!-- / Footer Navigation Menu -->

    <!-- Footer Social Menu -->

    <!-- / Footer Social Menu -->

    <!-- Copyright Notice -->
    <p class="copyright">
      Copyright © 2022 SSAFY by
      <a href="https://www.ssafy.com">광주4반 김영서 김세진</a>
    </p>
    <!-- / Copyright Notice -->
  </a-layout-footer>
  <!-- / Layout Footer -->
</template>

<script>
export default {
  data() {
    return {};
  },
};
</script>

<style lang="scss" scoped>
.nav-link svg {
  margin-right: 5px;
  vertical-align: middle;
}
.nav-link span {
  vertical-align: middle;
}
.ant-menu-submenu-popup {
  width: 100%;
}
</style>
