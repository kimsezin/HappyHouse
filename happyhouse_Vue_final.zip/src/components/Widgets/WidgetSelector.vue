<template>
  <a-card :bordered="false" class="widget-1">
    <!-- <a-statistic
      :title="title"
      :value="value"
      :prefix="prefix"
      :suffix="suffix"
      :precision="0"
      class="text-success"
      :class="'text-' + status"
    >
    </a-statistic> -->
    <div style="text-align: center; height: 61px; display: flex; align-items: center">
      <!-- 시/도/광역시 -->
      <a-select
        id="do-select"
        default-value="도/광역시"
        style="width: 33%"
        @change="handleChangeDo"
      >
        <a-select-option v-for="(item, index) in do_list" :key="index" :value="item.sidoCode">
          {{ item.sidoName }}
        </a-select-option>
      </a-select>
      <!-- 구/군 -->
      <a-select
        id="gugun-select"
        default-value="시/구/군"
        style="width: 33%; margin-left: 10%"
        @change="handleChangeGuGun"
      >
        <a-select-option v-for="(item, index) in gugun_list" :key="index" :value="item.gugunCode">
          {{ item.gugunName.split(" ")[1] }}
        </a-select-option>
      </a-select>
      <!-- 동/읍/면 -->
      <a-select
        default-value="동/읍/면"
        style="width: 33%; margin-left: 10%"
        @change="handleChangeDong"
      >
        <a-select-option v-for="(item, index) in dong_list" :key="index" :value="item.dongCode">
          {{ item.dongName.split(" ")[2] }}
        </a-select-option>
      </a-select>
    </div>
  </a-card>
</template>

<script>
import http from "@/api/http.js";
import { mapState, mapActions } from "vuex";

export default {
  data() {
    return {
      do_list: [],
      gugun_list: [],
      dong_list: [],
    };
  },
  async created() {
    await http.get("/map/sido").then((response) => {
      this.do_list = response.data;
    });
  },
  methods: {
    ...mapActions(["panTo", "setAptList"]),
    async handleChangeDo(value) {
      await http.get(`/map/gugun/${value}`).then((response) => {
        this.gugun_list = response.data;
      });
      let address = document.getElementById("do-select").innerText;
      this.panTo(address);
    },
    async handleChangeGuGun(value) {
      await http.get(`/map/dong/${value}`).then((response) => {
        this.dong_list = response.data;
      });
      let address =
        document.getElementById("do-select").innerText +
        " " +
        document.getElementById("gugun-select").innerText;
      this.panTo(address);
    },
    async handleChangeDong(value) {
      await http.get(`/house/${value}`).then((response) => {
        if (response.data.length != 0) {
          this.setAptList(response.data);
        } else {
          alert("선택하신 지역의 아파트 정보가 없습니다.");
        }
      });
    },
  },
};
</script>
