<!-- 
	This is the user profile page, it uses the dashboard layout in: 
	"./layouts/Dashboard.vue" .
 -->

<template>
  <div>
    <!-- Header Background Image -->
    <div
      class="profile-nav-bg"
      style="background-image: url('images/bg-profile.jpg')"
    ></div>

    <!-- / Header Background Image -->

    <!-- User Profile Card -->
    <a-card
      :bordered="false"
      class="card-profile-head"
      :bodyStyle="{ padding: 0 }"
    >
      <template #title>
        <a-row type="flex" align="middle">
          <a-col :span="24" :md="12" class="col-info">
            <!-- <a-avatar :size="74" shape="square" src="images/face-1.jpg" /> -->
            <div class="avatar-info">
              <h4 class="font-semibold m-0">{{ userInfo.userName }}</h4>
              <p v-if="userInfo.userId == 'admin'">Admin</p>
              <p v-else>Member</p>
            </div>
          </a-col>
          <a-col
            :span="24"
            :md="12"
            style="
              display: flex;
              align-items: center;
              justify-content: flex-end;
            "
          >
          </a-col>
        </a-row>
      </template>
    </a-card>
    <!-- User Profile Card -->

    <a-row type="flex" :gutter="24">
      <!-- Profile Information Column -->
      <a-col :span="24" :md="24" class="mb-24">
        <!-- Profile Information Card -->
        <CardProfileInformation></CardProfileInformation>
        <!-- / Profile Information Card -->
      </a-col>
    </a-row>
  </div>
</template>

<script>
import { mapState, mapActions, mapGetters } from "vuex";

import CardProfileInformation from "../components/Cards/CardProfileInformation";

export default {
  components: {
    CardProfileInformation,
  },
  data() {
    return {
      // Project cards data
      projects,
    };
  },
  computed: {
    ...mapState(["userInfo"]),
  },
  getters: {
    ...mapGetters(["checkUserInfo"]),
  },
  methods: {
    ...mapActions(["getUserInfo"]),
    print() {
      console.log(this.userInfo);
    },
  },
};
</script>

<style lang="scss"></style>
