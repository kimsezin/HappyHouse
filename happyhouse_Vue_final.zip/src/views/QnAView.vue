<!-- 
	This is the billing page, it uses the dashboard layout in: 
	"./layouts/Dashboard.vue" .
 -->

<template>
  <div>
    <a-row type="flex" :gutter="24">
      <!-- Billing Information Column -->
      <a-col :span="24" :md="boardMd" class="mb-24">
        <!-- Billing Information Card -->
        <CardQnABoard></CardQnABoard>
        <!-- / Billing Information Card -->
      </a-col>
      <!-- Billing Information Column -->

      <!-- Your Transactions Column -->
      <a-col :span="24" :md="commentMd" class="mb-24">
        <!-- Your Transactions Card -->
        <CardTransactions></CardTransactions>
        <!-- / Your Transactions Card -->
      </a-col>
      <!-- / Your Transactions Column -->
    </a-row>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import CardQnABoard from "../components/Cards/CardQnABoard";
import CardTransactions from "../components/Cards/CardTransactions";

export default {
  components: {
    CardQnABoard,
    CardTransactions,
  },
  data() {
    return {
      boardMd: 24,
      commentMd: 0,
    };
  },
  computed: {
    ...mapState(["clickBoard"]),
  },
  mounted() {
    this.setClickBoard(false);
  },
  watch: {
    clickBoard: function () {
      if (this.clickBoard) {
        this.boardMd = 16;
        this.commentMd = 8;
      }
    },
  },
  methods: {
    ...mapActions(["setClickBoard"]),
  },
};
</script>

<style lang="scss"></style>
