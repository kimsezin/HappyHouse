<!-- 
   This is the dashboard page, it uses the dashboard layout in: 
   "./layouts/DashboardRTL.vue" .
 -->

<template>
  <div>
    <!-- Charts -->
    <a-row :gutter="24" type="flex" align="stretch">
      <a-col :span="24" :lg="16" class="mb-24">
        <!-- Active Users Card -->
        <CardInterestMap></CardInterestMap>
        <!-- Active Users Card -->
      </a-col>
      <a-col :span="24" :lg="8" class="mb-24">
        <!-- Sales Overview Card -->
        <CardProjectTable
          v-if="infraOption == 'store'"
          :data="storeList"
          :columns="storeColumns"
        ></CardProjectTable>
        <CardProjectTable
          v-else
          :data="schoolList"
          :columns="schoolColumns"
        ></CardProjectTable>
        <!-- / Sales Overview Card -->
      </a-col>
    </a-row>
    <!-- / Charts -->
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";

// Bar chart for "Active Users" card.
import CardInterestMap from "../components/Cards/CardInterestMap";

// "Projects" table component.
import CardProjectTable from "../components/Cards/CardProjectTable";

const storeColumns = [
  {
    title: "",
    scopedSlots: { customRender: "moveBtn" },
    width: 50,
  },
  {
    title: "상호명",
    dataIndex: "storeName",
    class: "font-bold text-muted text-sm",
  },
  {
    title: "분류",
    dataIndex: "category",
    class: "font-bold text-muted text-sm",
  },
  {
    title: "주소",
    dataIndex: "address",
    class: "font-bold text-muted text-sm",
    width: 300,
  },
];

const schoolColumns = [
  {
    title: "",
    scopedSlots: { customRender: "moveBtn" },
    width: 50,
  },
  {
    title: "학교명",
    dataIndex: "schoolName",
    class: "font-bold text-muted text-sm",
  },
  {
    title: "설립형태",
    dataIndex: "category",
    class: "font-bold text-muted text-sm",
  },
  {
    title: "설립일자",
    dataIndex: "buildDate",
    class: "font-bold text-muted text-sm",
  },
  {
    title: "주소",
    dataIndex: "address",
    class: "font-bold text-muted text-sm",
    width: 300,
  },
];

export default {
  components: {
    CardInterestMap,
    CardProjectTable,
  },
  data() {
    return {
      // Associating table columns with its corresponding property.
      storeColumns,
      schoolColumns,
    };
  },
  computed: {
    ...mapState(["storeList", "schoolList", "infraOption"]),
  },
  mounted() {
    this.setStoreList([]);
    this.setSchoolList([]);
    this.setInfraOption("store");
  },
  methods: {
    ...mapActions(["setStoreList", "setSchoolList", "setInfraOption"]),
  },
};
</script>

<style lang="scss"></style>
