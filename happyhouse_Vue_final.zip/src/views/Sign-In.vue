<!-- 
	This is the sign in page, it uses the dashboard layout in: 
	"./layouts/Default.vue" .
 -->

<template>
  <div class="sign-in">
    <a-row type="flex" :gutter="[24, 24]" justify="space-around" align="middle">
      <!-- Sign In Form Column -->
      <a-col
        :span="24"
        :md="12"
        :lg="{ span: 12, offset: 0 }"
        :xl="{ span: 6, offset: 2 }"
        class="col-form"
      >
        <h1 class="mb-15">Sign In</h1>
        <h5 class="font-regular text-muted">Enter your email and password to sign in</h5>

        <!-- Sign In Form -->
        <a-input
          v-decorator="['ID', { rules: [{ required: true, message: 'Please input your ID!' }] }]"
          placeholder="ID"
          v-model="user.userId"
        />

        <a-input
          v-decorator="[
            'password',
            { rules: [{ required: true, message: 'Please input your password!' }] },
          ]"
          type="password"
          placeholder="Password"
          v-model="user.password"
        />
        <a-alert
          message="아이디 또는 비밀번호를 확인하세요."
          type="error"
          v-if="isLoginError"
          show-icon
        />
        <a-button type="primary" block class="login-form-button" @click="confirm">
          SIGN IN
        </a-button>

        <!-- / Sign In Form -->

        <p class="font-semibold text-muted">
          Don't have an account?
          <router-link to="/sign-up" class="font-bold text-dark">Sign Up</router-link>
        </p>
        <p class="font-semibold text-muted">
          Can't remember your password?
          <a @click="changeModalVisible" class="font-bold text-dark">Find Password</a>
          <a-modal v-model="modalVisible" title="Find Password" @ok="handleOk">
            <div class="col-info">
              ID :
              <a-input v-model="findUserId" placeholder="ID" />
              Email :
              <a-input v-model="findUserEmail" placeholder="Email" />
            </div>
          </a-modal>
        </p>
      </a-col>
      <!-- / Sign In Form Column -->

      <!-- Sign In Image Column -->
      <a-col :span="24" :md="12" :lg="12" :xl="12" class="col-img">
        <img src="images/img-signin.jpg" alt="" />
      </a-col>
      <!-- Sign In Image Column -->
    </a-row>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import http from "@/api/http.js";
export default {
  data() {
    return {
      // Binded model property for "Sign In Form" switch button for "Remember Me" .
      rememberMe: true,
      user: {
        userId: "",
        password: "",
      },
      findUserId: null,
      findUserEmail: null,
      modalVisible: false,
    };
  },
  beforeCreate() {
    // Creates the form and adds to it component's "form" property.
    this.form = this.$form.createForm(this, { name: "normal_login" });
  },
  created() {
    this.setIsLoginError(false);
  },
  methods: {
    // Handles input validation after submission.
    // handleSubmit(e) {
    //   e.preventDefault();
    //   this.form.validateFields((err, values) => {
    //     if (!err) {
    //       console.log("Received values of form: ", values);
    //     }
    //   });
    // },
  },
  computed: {
    ...mapState(["isLogin", "isLoginError"]), //로그인 여부 확인하기
  },
  methods: {
    ...mapActions(["userConfirm", "getUserInfo", "setIsLoginError"]),
    async confirm() {
      console.log(this.user);
      await this.userConfirm(this.user); //acations의 로그인 메소드 실행
      let token = sessionStorage.getItem("access-token"); //세션 스토리지에 토큰 가져오기
      if (this.isLogin) {
        //화면에 ~~~님 반갑습니다 표시하기 위해 유저정보 가져오기
        await this.getUserInfo(token); //토큰 들고가서 사용자 정보 가져오기
        this.$router.push({ name: "Home" });
      }
    },
    changeModalVisible() {
      this.modalVisible = true;
    },
    handleOk(e) {
      if (this.findUserEmail != null && this.findUserId != null) {
        http
          .get(`/user/password?userId=${this.findUserId}&email=${this.findUserEmail}`)
          .then((response) => {
            if (response.data.length != 0) {
              alert(`회원님의 비밀번호는 ${response.data} 입니다.`);
              this.modalVisible = false;
            } else {
              alert("회원가입시에 입력한 아이디와 비밀번호를 정확히 입력해주세요.");
            }
          });
      } else {
        alert("아이디와 이메일을 입력해주세요.");
      }
    },
  },
};
</script>

<style lang="scss">
body {
  background-color: #ffffff;
}
</style>
