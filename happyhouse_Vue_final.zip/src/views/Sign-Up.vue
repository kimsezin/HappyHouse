<!-- 
   This is the sign up page, it uses the dashboard layout in: 
   "./layouts/Default.vue" .
 -->

<template>
  <div>
    <!-- Sign Up Image And Headings -->
    <div class="sign-up-header" style="background-image: url('images/bg-signup.jpg')">
      <div class="content">
        <h1 class="mb-5">Sign Up</h1>
        <p class="text-lg">
          Use these awesome forms to login or create new account in your project for free.
        </p>
      </div>
    </div>
    <!-- / Sign Up Image And Headings -->

    <!-- Sign Up Form -->
    <a-card
      :bordered="false"
      class="card-signup header-solid h-full"
      :bodyStyle="{ paddingTop: 0 }"
    >
      <template #title>
        <h5 class="font-semibold text-center">Register</h5>
      </template>
      <a-form
        id="components-form-demo-normal-login"
        :form="form"
        class="login-form"
        @submit="handleSubmit"
      >
        <a-form-item class="mb-10">
          <a-input v-model="registInfo.userId" placeholder="ID"> </a-input>
        </a-form-item>
        <a-form-item class="mb-10">
          <a-input v-model="registInfo.password" type="password" placeholder="Password"> </a-input>
        </a-form-item>
        <a-form-item class="mb-5">
          <a-input v-model="registInfo.email" placeholder="Email"> </a-input>
        </a-form-item>
        <a-form-item class="mb-5">
          <a-input v-model="registInfo.address" placeholder="Address"> </a-input>
        </a-form-item>
        <a-form-item class="mb-5">
          <a-input v-model="registInfo.userName" placeholder="Name"> </a-input>
        </a-form-item>
        <a-form-item class="mb-5">
          <a-input
            type="text"
            v-model="registInfo.phone"
            placeholder="Phone"
            @keyup="getPhoneMask(registInfo.phone)"
          >
          </a-input>
        </a-form-item>
        <a-alert
          message="회원가입에 필요한 모든 항목을 작성해주세요."
          type="error"
          v-if="isRegistError"
          show-icon
        />
        <a-form-item>
          <a-button type="primary" block html-type="submit" class="login-form-button">
            SIGN UP
          </a-button>
        </a-form-item>
      </a-form>
      <p class="font-semibold text-muted text-center">
        Already have an account?
        <router-link to="/sign-in" class="font-bold text-dark">Sign In</router-link>
      </p>
    </a-card>
    <!-- / Sign Up Form -->
  </div>
</template>

<script>
import http from "@/api/http.js";
export default {
  data() {
    return {
      registInfo: {
        userId: null,
        password: null,
        email: null,
        address: null,
        userName: null,
        phone: null,
      },
      isRegistError: false,
    };
  },
  beforeCreate() {
    // Creates the form and adds to it component's "form" property.
    this.form = this.$form.createForm(this, { name: "normal_login" });
  },
  methods: {
    // Handles input validation after submission.
    handleSubmit(e) {
      if (
        this.registInfo.userId == null ||
        this.registInfo.password == null ||
        this.registInfo.email == null ||
        this.registInfo.address == null ||
        this.registInfo.userName == null ||
        this.registInfo.phone == null
      ) {
        this.isRegistError = true;
        return;
      }
      e.preventDefault();
      console.log(this.registInfo);
      console.log(this.registInfo.userId);
      http
        .post(
          `/user/register?email=${this.registInfo.email}&address=${this.registInfo.address}&password=${this.registInfo.password}&phone=${this.registInfo.phone}&userId=${this.registInfo.userId}&userName=${this.registInfo.userName}`
        )
        .then((response) => {
          alert("회원 가입이 완료되었습니다.");
          this.$router.push("/sign-in");
        })
        .catch((error) => {
          console.log(error);
        });
    },

    getPhoneMask(val) {
      let res = this.getMask(val);
      this.registInfo.phone = res;
      //서버 전송 값에는 '-' 를 제외하고 숫자만 저장
      //   this.model.phone = this.phone.replace(/[^0-9]/g, "");
    },

    getMask(phoneNumber) {
      if (!phoneNumber) return phoneNumber;
      phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

      let res = "";
      if (phoneNumber.length < 3) {
        res = phoneNumber;
      } else {
        if (phoneNumber.substr(0, 2) == "02") {
          if (phoneNumber.length <= 5) {
            //02-123-5678
            res = phoneNumber.substr(0, 2) + "-" + phoneNumber.substr(2, 3);
          } else if (phoneNumber.length > 5 && phoneNumber.length <= 9) {
            //02-123-5678
            res =
              phoneNumber.substr(0, 2) +
              "-" +
              phoneNumber.substr(2, 3) +
              "-" +
              phoneNumber.substr(5);
          } else if (phoneNumber.length > 9) {
            //02-1234-5678
            res =
              phoneNumber.substr(0, 2) +
              "-" +
              phoneNumber.substr(2, 4) +
              "-" +
              phoneNumber.substr(6);
          }
        } else {
          if (phoneNumber.length < 8) {
            res = phoneNumber;
          } else if (phoneNumber.length == 8) {
            res = phoneNumber.substr(0, 4) + "-" + phoneNumber.substr(4);
          } else if (phoneNumber.length == 9) {
            res =
              phoneNumber.substr(0, 3) +
              "-" +
              phoneNumber.substr(3, 3) +
              "-" +
              phoneNumber.substr(6);
          } else if (phoneNumber.length == 10) {
            res =
              phoneNumber.substr(0, 3) +
              "-" +
              phoneNumber.substr(3, 3) +
              "-" +
              phoneNumber.substr(6);
          } else if (phoneNumber.length > 10) {
            //010-1234-5678
            res =
              phoneNumber.substr(0, 3) +
              "-" +
              phoneNumber.substr(3, 4) +
              "-" +
              phoneNumber.substr(7);
          }
        }
      }
      console.log(res);
      return res;
    },
  },
};
</script>

<style lang="scss"></style>
