package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.service.BoardService;
import com.ssafy.happyhouse.controller.BoardController;
import com.ssafy.happyhouse.model.Board;
import com.ssafy.happyhouse.model.SearchDto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/board")
@CrossOrigin("*")
@Api("Controller REST V1")
public class BoardController {


	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	@Autowired
	private BoardService boardService;

    @ApiOperation(value = "모든 게시글의 정보를 반환한다.", response = List.class)
	@GetMapping
	public ResponseEntity<List<Board>> retrieveBoard() throws Exception {
		logger.debug("retrieveBoard - 호출");
//		System.out.println(boardService.retrieveBoard().get(0).getUserId());
		return new ResponseEntity<List<Board>>(boardService.retrieveBoard(), HttpStatus.OK);
	}

    @ApiOperation(value = "글번호에 해당하는 게시글의 정보를 반환한다.", response = Board.class)    
	@GetMapping("{articleNo}")
	public ResponseEntity<Board> detailBoard(@PathVariable int articleNo) {
		logger.debug("detailBoard - 호출");
		return new ResponseEntity<Board>(boardService.detailBoard(articleNo), HttpStatus.OK);
	}

    @ApiOperation(value = "새로운 게시글 정보를 입력한다. 그리고 DB입력 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@PostMapping
	public ResponseEntity<String> writeBoard(@RequestBody Board board) {
		logger.debug("writeBoard - 호출");
		if (boardService.writeBoard(board)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}

    @ApiOperation(value = "글번호에 해당하는 게시글의 정보를 수정한다. 그리고 DB수정 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@PutMapping("{articleNo}")
	public ResponseEntity<String> updateBoard(@RequestBody Board board) {
		logger.debug("updateBoard - 호출");
		logger.debug("" + board);
		
		if (boardService.updateBoard(board)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}

    @ApiOperation(value = "글번호에 해당하는 게시글의 정보를 삭제한다. 그리고 DB삭제 성공여부에 따라 'success' 또는 'fail' 문자열을 반환한다.", response = String.class)
	@DeleteMapping("{articleNo}")
	public ResponseEntity<String> deleteBoard(@PathVariable int articleNo) {
		logger.debug("deleteBoard - 호출");
		if (boardService.deleteBoard(articleNo)) {
			return new ResponseEntity<String>(SUCCESS, HttpStatus.OK);
		}
		return new ResponseEntity<String>(FAIL, HttpStatus.NO_CONTENT);
	}
    
    @ApiOperation(value = "key(userid, subject, content) 에 따른검색한 word가 있는 board 반환.", response = List.class)
   	@GetMapping("list/{key}")
   	public ResponseEntity<List<Board>> searchBoard(@PathVariable String key, @RequestParam("word") String word, @RequestParam("currentPage") int currentPage) throws Exception {
   		SearchDto searchDto = new SearchDto();
   		searchDto.setKey(key);
   		searchDto.setWord(word);
   		searchDto.setCurrentPage(currentPage);
   		return new ResponseEntity<List<Board>>(boardService.searchBoard(searchDto), HttpStatus.OK);
   	}
    
    @ApiOperation(value = "검색된 게시물의 총 개수를 반환", response = Integer.class)
   	@GetMapping("/search/count")
   	public ResponseEntity<Integer> searchCount(@RequestParam("key") String key, @RequestParam("word") String word) throws Exception {
   		SearchDto searchDto = new SearchDto();
   		searchDto.setKey(key);
   		searchDto.setWord(word);
    	return new ResponseEntity<Integer>(boardService.searchCount(searchDto), HttpStatus.OK);
   	}
    
    @ApiOperation(value = "게시물의 총 개수를 반환", response = Integer.class)
   	@GetMapping("/count")
   	public ResponseEntity<Integer> boardCount() throws Exception {
   		return new ResponseEntity<Integer>(boardService.boardCount(), HttpStatus.OK);
   	}
    
    @ApiOperation(value = "currentPage부터 5개의 게시물을 반환", response = List.class)
	@GetMapping("/pagination/{currentPage}")
	public ResponseEntity<List<Board>> selectBoardPagination(@PathVariable int currentPage) throws Exception {
		return new ResponseEntity<List<Board>>(boardService.selectBoardPagination(currentPage), HttpStatus.OK);
	}
}
