package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.Board;
import com.ssafy.happyhouse.model.CommentDto;
import com.ssafy.happyhouse.model.service.CommentService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/comment")
@CrossOrigin("*")
@Api("Controller REST V1")
public class CommentController {
	
	private static final Logger logger = LoggerFactory.getLogger(CommentController.class);
	
	@Autowired
	private CommentService commentService;
	
	@ApiOperation(value = "댓글 리스트", notes = "해당 게시글의 모든 댓글 목록 반환")
	@GetMapping("/{articleNo}")
	public ResponseEntity<List<CommentDto>> getCommentList(@PathVariable int articleNo) throws Exception {
		return new ResponseEntity<List<CommentDto>>(commentService.getCommentList(articleNo), HttpStatus.OK);
	}
	
	@ApiOperation(value = "새로운 댓글 등록", notes = "성공시 1 반환, 실패시 0 반환")
	@PostMapping
	public ResponseEntity<Integer> insertComment(@RequestParam int articleNo, @RequestParam String content, @RequestParam String userId) throws Exception {
		CommentDto commentDto = new CommentDto();
		commentDto.setArticleNo(articleNo);
		commentDto.setContent(content);
		commentDto.setUserId(userId);
		return new ResponseEntity<Integer>(commentService.insertComment(commentDto), HttpStatus.OK);
	}
	
	@ApiOperation(value = "댓글 삭제", notes = "성공시 1 반환, 실패시 0 반환")
	@DeleteMapping("/{commentNo}")
	public ResponseEntity<Integer> deleteComment(@PathVariable int commentNo) throws Exception {
		return new ResponseEntity<Integer>(commentService.deleteComment(commentNo), HttpStatus.OK);
	}
	
	@ApiOperation(value = "댓글 수정", notes = "성공시 1 반환, 실패시 0 반환")
	@PutMapping
	public ResponseEntity<Integer> updateComment(@RequestParam int commentNo, @RequestParam String content) throws Exception {
		CommentDto commentDto = new CommentDto();
		commentDto.setCommentNo(commentNo);
		commentDto.setContent(content);
		return new ResponseEntity<Integer>(commentService.updateComment(commentDto), HttpStatus.OK);
	}
}
