package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.HouseDealDto;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.SidoGugunCodeDto;
import com.ssafy.happyhouse.model.service.HouseService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/house")
@CrossOrigin("*")
@Api("Controller REST V1")
public class HouseDealController {
	private final Logger logger = LoggerFactory.getLogger(HouseDealController.class);

	@Autowired
	private HouseService houseService;

	@ApiOperation(value = "아파트 거래 목록", notes = "해당 동 아파트 거래 목록 리턴")
	@ApiResponses({ @ApiResponse(code = 404, message = "주소 오류 !!!"), @ApiResponse(code = 500, message = "서버 에러 !!!"),
			@ApiResponse(code = 200, message = "회원 목록 정상 처리") })
	@GetMapping("/deal/{dongcode}")
	public ResponseEntity<List<HouseDealDto>> showDealList(@PathVariable String dongcode) throws Exception {
		return new ResponseEntity<List<HouseDealDto>>(houseService.dealList(dongcode), HttpStatus.OK);
	}

	@ApiOperation(value = "특정 아파트 거래 목록 리스트", notes = "aptNo에 해당하는 아파트 거래 목록 리턴")
	@GetMapping("/list/{aptNo}")
	public ResponseEntity<List<HouseDealDto>> showAptDealList(@PathVariable int aptNo) throws Exception {
		return new ResponseEntity<List<HouseDealDto>>(houseService.aptDealList(aptNo), HttpStatus.OK);
	}

	@ApiOperation(value = "특정 유저가 선택한 관심 아파트 리스트", notes = "userId에 맞는 관심 아파트 목록 리턴")
	@GetMapping("/interest/list/{userId}")
	public ResponseEntity<List<HouseInfoDto>> getInterestList(@PathVariable String userId) throws Exception {
		return new ResponseEntity<List<HouseInfoDto>>(houseService.getInterestList(userId), HttpStatus.OK);
	}
	
	@ApiOperation(value = "특정 유저의 특정 아파트 관심 추가 여부", notes = "관심 목록에 있으면 1 반환 없으면 0 반환")
	@GetMapping("/interest")
	public ResponseEntity<Integer> getInterestList(@RequestParam String userId, @RequestParam int aptNo) throws Exception {
		return new ResponseEntity<Integer>(houseService.getInterest(userId, aptNo), HttpStatus.OK);
	}
	
	@ApiOperation(value = "특정 유저의 관심 아파트 추가", notes = "성공하면 1 반환 실패하면 0 반환")
	@PostMapping("/interest")
	public ResponseEntity<Integer> insertInterest(@RequestParam String userId, @RequestParam int aptNo) throws Exception {
		return new ResponseEntity<Integer>(houseService.insertInterest(userId, aptNo), HttpStatus.OK);
	}
	
	@ApiOperation(value = "특정 유저의 관심 아파트 제거", notes = "성공하면 1 반환 실패하면 0 반환")
	@DeleteMapping("/interest")
	public ResponseEntity<Integer> deleteInterest(@RequestParam String userId, @RequestParam int aptNo) throws Exception {
		return new ResponseEntity<Integer>(houseService.deleteInterest(userId, aptNo), HttpStatus.OK);
	}

//	@ApiOperation(value = "아파트 상세페이지", notes = "선택한 아파트 정보 리턴")
//	@GetMapping("/detail2")
//	public ResponseEntity<List<HouseDealDto>> showDetailList(@RequestBody HouseDealDto houseDealDto) throws Exception {
//		//logger.debug("here !!!!!!!!!!! list : {}", houseService.detailList(houseDealDto.getDongCode(), houseDealDto.getAptName()));
//		return new ResponseEntity<List<HouseDealDto>>(houseService.detailList(houseDealDto.getDongCode(), houseDealDto.getAptName()), HttpStatus.OK);
//	}

	@ApiOperation(value = "아파트 목록", notes = "동코드에 해당하는 아파트 목록 리턴")
	@GetMapping("/{dongCode}")
	public ResponseEntity<List<HouseInfoDto>> aptList(@PathVariable String dongCode) throws Exception {
		return new ResponseEntity<List<HouseInfoDto>>(houseService.aptList(dongCode), HttpStatus.OK);
	}
	
	@ApiOperation(value = "가장 비싸게 거래된 아파트", notes = "xxxx년 xx월에 가장 비싸게 거래된 아파트 리턴")
	@GetMapping("/amount")
	public ResponseEntity<String> getMaxDealAmount() throws Exception {
		return new ResponseEntity<String>(houseService.getMaxDealAmount(), HttpStatus.OK);
	}
	
	@ApiOperation(value = "가장 많이 관심받은 아파트", notes = "관심 목록에 가장 많이 추가된 아파트 리턴")
	@GetMapping("/favorite")
	public ResponseEntity<String> getMostInterest() throws Exception {
		return new ResponseEntity<String>(houseService.getMostInterest(), HttpStatus.OK);
	}
	
}
