package com.ssafy.happyhouse.controller;

import java.net.URLDecoder;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.SchoolDto;
import com.ssafy.happyhouse.model.StoreDto;
import com.ssafy.happyhouse.model.service.InfraService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/infra")
@CrossOrigin("*")
@Api("Controller REST V1")
public class InfraController {
	private final Logger logger = LoggerFactory.getLogger(InfraController.class);
	
	@Autowired
	private InfraService infraService;
	
	@ApiOperation(value = "관심있는 아파트 근처 음식점 리스트", notes = "dongCode에 해당하는 음식점 목록 리턴")
	@GetMapping("/store/{dongCode}")
	public ResponseEntity<List<StoreDto>> getStoreList(@PathVariable String dongCode) throws Exception {
		return new ResponseEntity<List<StoreDto>>(infraService.getStoreList(dongCode), HttpStatus.OK);
	}
	
	@ApiOperation(value = "중심 좌표 근처의 음식점 리스트", notes ="중심 좌표 근처의 음식점 목록을 가까운 순으로 150개 반환")
	@GetMapping("/store")
	public ResponseEntity<List<StoreDto>> getAdjStoreList(@RequestParam("address") String address, @RequestParam("lat") String curLat, @RequestParam("lng") String curLng) throws Exception {
		
		String decodeVal = URLDecoder.decode(address, "utf-8");
		System.out.println(decodeVal);
		return new ResponseEntity<List<StoreDto>>(infraService.getAdjStoreList(decodeVal, curLat, curLng), HttpStatus.OK);
	}
	
	@ApiOperation(value = "중심 좌표 근처의 학교 리스트", notes ="중심 좌표 근처의 학교 목록을 가까운 순으로 20개 반환")
	@GetMapping("/school")
	public ResponseEntity<List<SchoolDto>> getAdjSchoolList(@RequestParam("lat") String curLat, @RequestParam("lng") String curLng) throws Exception {
		return new ResponseEntity<List<SchoolDto>>(infraService.getAdjSchoolList(curLat, curLng), HttpStatus.OK);
	}
}
