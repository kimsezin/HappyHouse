package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.HouseDealDto;
import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.service.UserService;
import com.ssafy.happyhouse.model.service.jwtService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/user")
@CrossOrigin("*")
@Api("Controller REST V1")
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	private jwtService jwtService;
	
	@Autowired
	private UserService userService;

	@ApiOperation(value = "idcheck 맞으면 1 틀리면 0", notes = "회원의 <big>전체 목록</big>을 리턴.")
	@GetMapping("/idcheck")
	public ResponseEntity<Integer> idCheck(@RequestParam("ckid") String checkId) throws Exception
	{
		return new ResponseEntity<Integer>(userService.idCheck(checkId), HttpStatus.OK);
	}
//	public @ResponseBody String idCheck(@RequestParam("ckid") String checkId) throws Exception { //@ResponseBody로 넘겨주면 알아서 json으로
//		int idCount = userService.idCheck(checkId);
//		JSONObject json = new JSONObject();
//		json.put("idcount", idCount);
//		return json.toString();
//	}
	
	@ApiOperation(value = "회원가입", notes = "회원 가입 성공 시 1, 실패시 0")
	@PostMapping("/register")
	public ResponseEntity<Integer> register(@RequestBody UserDto userDto) throws Exception {
		return new ResponseEntity<Integer>(userService.registerUser(userDto), HttpStatus.CREATED);
		
	}
	@ApiOperation(value = "회원 정보", notes = "특정 회원의 정보 리턴")
	@GetMapping("/{id}")
	public ResponseEntity<UserDto> getUser(@PathVariable String id) throws Exception {
		return new ResponseEntity<UserDto>(userService.getUser(id), HttpStatus.OK);
	}
	
	@ApiOperation(value = "비밀번호 찾기", notes = "아이디와 이메일을 입력 받아 비밀번호 리턴")
	@GetMapping("/password")
	public ResponseEntity<String> findPassword(@RequestParam String userId, @RequestParam String email) throws Exception {
		return new ResponseEntity<String>(userService.findPassword(userId, email), HttpStatus.OK);
	}
	
	@ApiOperation(value = "회원 설명 수정", notes = "회원 설명 수정")
	@PostMapping("/desc")
	//public String deleteUser(@RequestParam String userId, HttpSession session) {
	public ResponseEntity<Integer> updateDesc(@RequestBody UserDto userDto) throws Exception
	{
		return new ResponseEntity<Integer>(userService.updateDesc(userDto), HttpStatus.OK);
	}
//	@PostMapping("/login")
//	public String login(@RequestParam Map<String,String> map, Model model, HttpSession session,
//			HttpServletResponse response) {
//		logger.debug("map : {}", map.get("userId"));
//		try {
//			//UserDto userDto = userService.getUser(map);
//			if (userDto != null) {
//				session.setAttribute("userInfo", userDto);
//				return "redirect:/";
//			}
//			else {
//				model.addAttribute("msg", "아이디 또는 비밀번호 확인 후 다시 로그인하세요!");
//				return "user/login";
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			model.addAttribute("msg", "오류가 발생하였습니다.");
//			return "redirect:/";
//		}
//	}
	
//	@GetMapping("/logout")
//	public String logout(HttpSession session) {
//		session.invalidate();
//		return "redirect:/";
//	}
	
	@ApiOperation(value = "회원탈퇴", notes = "회원 탈퇴 성공 시 1, 실패 시 0")
	@PostMapping("/delete")
	//public String deleteUser(@RequestParam String userId, HttpSession session) {
	public ResponseEntity<Integer> deleteUser(@RequestParam String userId) throws Exception
	{
		return new ResponseEntity<Integer>(userService.deleteUser(userId), HttpStatus.OK);
	}
	
	@ApiOperation(value = "로그인", notes = "로그인")
	@PostMapping("/login")
	public ResponseEntity<Map<String, Object>> login(@RequestBody UserDto userDto) {
		
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
		logger.info("로그인 요청");
		logger.info("userDto 정보 : {}", userDto.toString());

		try {
			UserDto loginUser = userService.login(userDto);
			if (loginUser != null) {
				String accessToken = jwtService.createAccessToken("userid", loginUser.getUserId());// key, data
				String refreshToken = jwtService.createRefreshToken("userid", loginUser.getUserId());
				userService.saveRefreshToken(userDto.getUserId(), refreshToken);
				logger.debug("access토큰정보 : {}", accessToken);
				logger.debug("refresh 토큰정보 : {}", refreshToken);
				resultMap.put("access-token", accessToken);
				resultMap.put("refresh-token", refreshToken);
				resultMap.put("message", SUCCESS);
				status = HttpStatus.ACCEPTED;
			} else {
				resultMap.put("message", FAIL);
				status = HttpStatus.ACCEPTED;
			}
		} catch (Exception e) {
			logger.error("로그인 실패 : {}", e);
			resultMap.put("message", e.getMessage());
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
	
	@ApiOperation(value = "사용자 정보 조회", notes = "사용자 정보 조회")
	@GetMapping("/info/{userid}")
	public ResponseEntity<Map<String, Object>> getInfo(@PathVariable("userid") String userId,
			HttpServletRequest request) {
		logger.debug("userId : {} ", userId);
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = HttpStatus.UNAUTHORIZED;
		System.out.println(request.getHeader("Host"));
		System.out.println(request.getHeader("access-token"));
		System.out.println(jwtService.checkToken(request.getHeader("access-token")));
		if (jwtService.checkToken(request.getHeader("access-token"))) {
			logger.info("사용 가능한 토큰!!!");
			try {
//				로그인 사용자 정보.
				UserDto userDto = userService.userInfo(userId);
				resultMap.put("userInfo", userDto);
				resultMap.put("message", SUCCESS);
				status = HttpStatus.ACCEPTED;
			} catch (Exception e) {
				logger.error("정보조회 실패 : {}", e);
				resultMap.put("message", e.getMessage());
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
		} else {
			logger.error("사용 불가능 토큰!!!");
			resultMap.put("message", FAIL);
			status = HttpStatus.UNAUTHORIZED;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
	
	@PutMapping("logout/{userid}")
	public ResponseEntity<?> removeToken(@PathVariable("userid") String userId){
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = HttpStatus.ACCEPTED;
		
		try {
			userService.deleRefreshToken(userId);
			resultMap.put("message", SUCCESS);
			status = HttpStatus.ACCEPTED;
		} catch (Exception e) {
			logger.error("로그아웃 실패 : {}", e);
			resultMap.put("message", e.getMessage());
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
	
	@PostMapping("/refresh")
	public ResponseEntity<?> refreshToken(@RequestBody UserDto user, HttpServletRequest request) throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = HttpStatus.ACCEPTED;
		String token = request.getHeader("refresh-token");
		jwtService.checkToken(token);
		
		if(token.equals(userService.getRefreshToken(user.getUserId()))) {
			String accessToken= jwtService.createAccessToken("userid", user.getUserId());
			resultMap.put("access-token", accessToken);
			resultMap.put("message", SUCCESS);
			status = HttpStatus.ACCEPTED;
		}else {
			status = HttpStatus.UNAUTHORIZED;
		}
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
}
