package com.ssafy.happyhouse.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CommentDto {
	private int commentNo;
	private int articleNo;
	private String userId;
	private String content;
	private String regtime;
	
	public CommentDto() {}

	public CommentDto(int commentNo, int articleNo, String userId, String content, String regtime) {
		super();
		this.commentNo = commentNo;
		this.articleNo = articleNo;
		this.userId = userId;
		this.content = content;
		this.regtime = regtime;
	}

	public int getCommentNo() {
		return commentNo;
	}

	public void setCommentNo(int commentNo) {
		this.commentNo = commentNo;
	}

	public int getArticleNo() {
		return articleNo;
	}

	public void setArticleNo(int articleNo) {
		this.articleNo = articleNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegtime() {
		return regtime;
	}

	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}

	@Override
	public String toString() {
		return "CommentDto [commentNo=" + commentNo + ", articleNo=" + articleNo + ", userId=" + userId + ", content="
				+ content + ", regtime=" + regtime + "]";
	}
	
}
