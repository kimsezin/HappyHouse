package com.ssafy.happyhouse.model;

public class HouseInfoDto {
	private int aptNo;
	private String aptName;
	private String dongCode;
	private String dongName;
	private int buildYear;
	private String address;
	private String jibun;
	private String lat;
	private String lng;
	
	public HouseInfoDto() {}
	
	public HouseInfoDto(int aptNo, String aptName, String dongCode, String dongName, int buildYear, String address,
			String jibun, String lat, String lng) {
		super();
		this.aptNo = aptNo;
		this.aptName = aptName;
		this.dongCode = dongCode;
		this.dongName = dongName;
		this.buildYear = buildYear;
		this.address = address;
		this.jibun = jibun;
		this.lat = lat;
		this.lng = lng;
	}

	public int getAptNo() {
		return aptNo;
	}

	public void setAptNo(int aptNo) {
		this.aptNo = aptNo;
	}

	public String getAptName() {
		return aptName;
	}

	public void setAptName(String aptName) {
		this.aptName = aptName;
	}

	public String getDongCode() {
		return dongCode;
	}

	public void setDongCode(String dongCode) {
		this.dongCode = dongCode;
	}

	public String getDongName() {
		return dongName;
	}

	public void setDongName(String dongName) {
		this.dongName = dongName;
	}

	public int getBuildYear() {
		return buildYear;
	}

	public void setBuildYear(int buildYear) {
		this.buildYear = buildYear;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getJibun() {
		return jibun;
	}

	public void setJibun(String jibun) {
		this.jibun = jibun;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	@Override
	public String toString() {
		return "HouseInfoDto [aptNo=" + aptNo + ", aptName=" + aptName + ", dongCode=" + dongCode + ", dongName="
				+ dongName + ", buildYear=" + buildYear + ", address=" + address + ", jibun=" + jibun + ", lat=" + lat
				+ ", lng=" + lng + "]";
	}
	
}
