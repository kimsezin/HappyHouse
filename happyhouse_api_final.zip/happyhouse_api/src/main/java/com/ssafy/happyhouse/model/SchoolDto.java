package com.ssafy.happyhouse.model;

public class SchoolDto {
	private String schoolId;
	private String schoolName;
	private String buildDate;
	private String category;
	private String address;
	private String lat;
	private String lng;
	
	public SchoolDto() {}

	public SchoolDto(String schoolId, String schoolName, String buildDate, String category, String address, String lat,
			String lng) {
		super();
		this.schoolId = schoolId;
		this.schoolName = schoolName;
		this.buildDate = buildDate;
		this.category = category;
		this.address = address;
		this.lat = lat;
		this.lng = lng;
	}

	public String getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(String schoolId) {
		this.schoolId = schoolId;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getBuildDate() {
		return buildDate;
	}

	public void setBuildDate(String buildDate) {
		this.buildDate = buildDate;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	@Override
	public String toString() {
		return "SchoolDto [schoolId=" + schoolId + ", schoolName=" + schoolName + ", buildDate=" + buildDate
				+ ", category=" + category + ", address=" + address + ", lat=" + lat + ", lng=" + lng + "]";
	}
	
}
