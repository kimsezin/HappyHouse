package com.ssafy.happyhouse.model;

public class SearchDto {
	private String key;
	private String word;
	private int currentPage;
	
	public SearchDto() {}

	public SearchDto(String key, String word, int currentPage) {
		super();
		this.key = key;
		this.word = word;
		this.currentPage = currentPage;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	@Override
	public String toString() {
		return "SearchDto [key=" + key + ", word=" + word + ", currentPage=" + currentPage + "]";
	}
	
}
