package com.ssafy.happyhouse.model;

public class StoreDto {
	private String storeNo;
	private String storeName;
	private String dongCode;
	private String category;
	private String address;
	private String lat;
	private String lng;
	
	public StoreDto() {}

	public StoreDto(String storeNo, String storeName, String dongCode, String category, String address, String lat,
			String lng) {
		super();
		this.storeNo = storeNo;
		this.storeName = storeName;
		this.dongCode = dongCode;
		this.category = category;
		this.address = address;
		this.lat = lat;
		this.lng = lng;
	}

	public String getStoreNo() {
		return storeNo;
	}

	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getDongCode() {
		return dongCode;
	}

	public void setDongCode(String dongCode) {
		this.dongCode = dongCode;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	@Override
	public String toString() {
		return "Store [storeNo=" + storeNo + ", storeName=" + storeName + ", dongCode=" + dongCode + ", category="
				+ category + ", address=" + address + ", lat=" + lat + ", lng=" + lng + "]";
	}
	
}
