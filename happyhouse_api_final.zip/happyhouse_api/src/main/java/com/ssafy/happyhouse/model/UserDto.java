package com.ssafy.happyhouse.model;

public class UserDto {
	private String userId;
	private String password;
	private String email;
	private String userName;
	private String address;
	private String phone;
	private String description;
	
	public UserDto() {}
	
	public UserDto(String userId, String password, String email, String userName, String address, String phone,
			String description) {
		super();
		this.userId = userId;
		this.password = password;
		this.email = email;
		this.userName = userName;
		this.address = address;
		this.phone = phone;
		this.description = description;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "UserDto [userId=" + userId + ", password=" + password + ", email=" + email + ", userName=" + userName
				+ ", address=" + address + ", phone=" + phone + ", description=" + description + "]";
	}
	
}
