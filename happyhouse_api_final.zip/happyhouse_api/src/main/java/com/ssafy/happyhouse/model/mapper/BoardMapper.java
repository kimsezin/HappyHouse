package com.ssafy.happyhouse.model.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.Board;
import com.ssafy.happyhouse.model.SearchDto;
@Mapper
public interface BoardMapper {
	public List<Board> selectBoard();
	public Board selectBoardByNo(int articleNo);
	public int insertBoard(Board board);
	public int updateBoard(Board board);
	public int deleteBoard(int articleNo);
	public List<Board> searchBoard(SearchDto searchDto);
	public int searchCount(SearchDto searchDto);
	public int boardCount();
	public List<Board> selectBoardPagination(int currentPage);
}