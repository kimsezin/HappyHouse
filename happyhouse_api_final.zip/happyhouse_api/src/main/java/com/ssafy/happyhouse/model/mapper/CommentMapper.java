package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.CommentDto;

@Mapper
public interface CommentMapper {
	public List<CommentDto> getCommentList(int articleNo) throws Exception;
	public int insertComment(CommentDto commentDto) throws Exception;
	public int deleteComment(int commentNo) throws Exception;
	public int updateComment(CommentDto commentDto) throws Exception;
}
