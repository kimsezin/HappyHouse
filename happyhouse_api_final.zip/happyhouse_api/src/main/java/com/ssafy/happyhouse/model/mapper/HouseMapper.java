package com.ssafy.happyhouse.model.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.Criteria;
import com.ssafy.happyhouse.model.HouseDealDto;
import com.ssafy.happyhouse.model.HouseInfoDto;

@Mapper
public interface HouseMapper {
	
	List<HouseDealDto> dealList(String dongCode) throws Exception;
	List<HouseDealDto> detailList(String dongCode, String aptName) throws Exception;
	List<HouseDealDto> pageList(Criteria cri);
	int getListCnt(String dongCode);
	List<HouseInfoDto> aptList(String dongCode) throws Exception;
	List<HouseDealDto> aptDealList(int aptNo) throws Exception;
	List<HouseInfoDto> getInterestList(String userId) throws Exception;
	int getInterest(Map<String, String> map) throws Exception;
	int insertInterest(Map<String, String> map) throws Exception;
	int deleteInterest(Map<String, String> map) throws Exception;
	String getMaxDealAmount() throws Exception;
	String getMostInterest() throws Exception;
}
