package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.SchoolDto;
import com.ssafy.happyhouse.model.StoreDto;

@Mapper
public interface InfraMapper {
	List<StoreDto> getStoreList(String dongCode) throws Exception;
	List<StoreDto> getAdjStoreList(String address, String curLat, String curLng) throws Exception;
	List<SchoolDto> getAdjSchoolList(String curLat, String curLng) throws Exception;
}
