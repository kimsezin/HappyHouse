package com.ssafy.happyhouse.model.mapper;

import java.sql.SQLException;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.model.UserDto;

@Mapper
public interface UserMapper {

	int idCheck(String userId) throws Exception;
	int registerUser(UserDto userDto) throws Exception;
	UserDto getUser(String userId) throws Exception;
	String findPassword(Map<String, String> map) throws Exception;
	int deleteUser(String userId) throws Exception;
	UserDto login(UserDto userDto) throws Exception;
	void saveRefreshToken(Map<String, String> map) throws SQLException;
	UserDto userInfo(String userId) throws SQLException;
	void deleteRefreshToken(Map<String, String> map) throws SQLException;
	String getRefreshToken(String userId) throws SQLException;
	Integer updateDesc(UserDto userDto);
}
