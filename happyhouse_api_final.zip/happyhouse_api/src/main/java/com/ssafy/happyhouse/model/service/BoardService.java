package com.ssafy.happyhouse.model.service;

import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.Board;
import com.ssafy.happyhouse.model.SearchDto;

public interface BoardService {
	public List<Board> retrieveBoard();
	public Board detailBoard(int articleNo);
	public boolean writeBoard(Board board);
	public boolean updateBoard(Board board);
	public boolean deleteBoard(int articleNo);
	public List<Board> searchBoard(SearchDto searchDto);
	public int searchCount(SearchDto searchDto);
	public int boardCount();
	public List<Board> selectBoardPagination(int currentPage);
}
