package com.ssafy.happyhouse.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.model.Board;
import com.ssafy.happyhouse.model.SearchDto;
import com.ssafy.happyhouse.model.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService{
	 @Autowired
		private BoardMapper boardMapper;

	    @Override
		public List<Board> retrieveBoard() {
			return boardMapper.selectBoard();
		}
	    
	  	@Override
		public boolean writeBoard(Board board) {
			return boardMapper.insertBoard(board) == 1;
		}

		@Override
		public Board detailBoard(int articleNo) {
			return boardMapper.selectBoardByNo(articleNo);
		}

		@Override
		@Transactional
		public boolean updateBoard(Board board) {
			return boardMapper.updateBoard(board) == 1;
		}

		@Override
		@Transactional
		public boolean deleteBoard(int articleNo) {
			return boardMapper.deleteBoard(articleNo) == 1;
		}

		@Override
		public List<Board> searchBoard(SearchDto searchDto) {
			return boardMapper.searchBoard(searchDto);
		}

		@Override
		public int boardCount() {
			return boardMapper.boardCount();
		}

		@Override
		public List<Board> selectBoardPagination(int currentPage) {
			return boardMapper.selectBoardPagination(currentPage);
		}

		@Override
		public int searchCount(SearchDto searchDto) {
			return boardMapper.searchCount(searchDto);
		}
}
