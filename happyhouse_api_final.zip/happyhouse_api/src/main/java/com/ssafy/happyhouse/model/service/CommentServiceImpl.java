package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.CommentDto;
import com.ssafy.happyhouse.model.mapper.CommentMapper;

@Service
public class CommentServiceImpl implements CommentService{

	@Autowired
	private CommentMapper commentMapper;
	
	@Override
	public List<CommentDto> getCommentList(int articleNo) throws Exception {
		return commentMapper.getCommentList(articleNo);
	}

	@Override
	public int insertComment(CommentDto commentDto) throws Exception {
		return commentMapper.insertComment(commentDto);
	}

	@Override
	public int deleteComment(int commentNo) throws Exception {
		return commentMapper.deleteComment(commentNo);
	}

	@Override
	public int updateComment(CommentDto commentDto) throws Exception {
		return commentMapper.updateComment(commentDto);
	}

}
