package com.ssafy.happyhouse.model.service;

import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.model.Criteria;
import com.ssafy.happyhouse.model.HouseDealDto;
import com.ssafy.happyhouse.model.HouseInfoDto;

public interface HouseService {
	
	List<HouseDealDto> dealList(String dongCode) throws Exception;
	List<HouseDealDto> detailList(String dongCode, String aptName) throws Exception;
	int getListCnt(String dongCode);
	List<HouseDealDto> pageList(Criteria cri);
	List<HouseInfoDto> aptList(String dongCode) throws Exception;
	List<HouseDealDto> aptDealList(int aptNo) throws Exception;
	List<HouseInfoDto> getInterestList(String userId) throws Exception;
	int getInterest(String userId, int aptNo) throws Exception;
	int insertInterest(String userId, int aptNo) throws Exception;
	int deleteInterest(String userId, int aptNo) throws Exception;
	String getMaxDealAmount() throws Exception;
	String getMostInterest() throws Exception;
}
