package com.ssafy.happyhouse.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.Criteria;
import com.ssafy.happyhouse.model.HouseDealDto;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.mapper.HouseMapper;

@Service
public class HouseServiceImpl implements HouseService {

	@Autowired
	private HouseMapper houseMapper;

	@Override
	public List<HouseDealDto> dealList(String dongCode) throws Exception {
		return houseMapper.dealList(dongCode);
	}

	@Override
	public List<HouseDealDto> detailList(String dongCode, String aptName) throws Exception {
		return houseMapper.detailList(dongCode, aptName);
	}

	@Override
	public int getListCnt(String dongCode) {
		return houseMapper.getListCnt(dongCode);
	}

	@Override
	public List<HouseDealDto> pageList(Criteria cri) {
		return houseMapper.pageList(cri);
	}

	@Override
	public List<HouseInfoDto> aptList(String dongCode) throws Exception {
		return houseMapper.aptList(dongCode);
	}

	@Override
	public List<HouseDealDto> aptDealList(int aptNo) throws Exception {
		return houseMapper.aptDealList(aptNo);
	}

	@Override
	public List<HouseInfoDto> getInterestList(String userId) throws Exception {
		return houseMapper.getInterestList(userId);
	}

	@Override
	public int getInterest(String userId, int aptNo) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("aptNo", Integer.toString(aptNo));
		return houseMapper.getInterest(map);
	}

	@Override
	public int insertInterest(String userId, int aptNo) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("aptNo", Integer.toString(aptNo));
		return houseMapper.insertInterest(map);
	}

	@Override
	public int deleteInterest(String userId, int aptNo) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("aptNo", Integer.toString(aptNo));
		return houseMapper.deleteInterest(map);
	}

	@Override
	public String getMaxDealAmount() throws Exception {
		return houseMapper.getMaxDealAmount();
	}

	@Override
	public String getMostInterest() throws Exception {
		return houseMapper.getMostInterest();
	}
}
