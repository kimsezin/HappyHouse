package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.SchoolDto;
import com.ssafy.happyhouse.model.StoreDto;


public interface InfraService {
	List<StoreDto> getStoreList(String dongCode) throws Exception;
	List<StoreDto> getAdjStoreList(String address, String curLat, String curLng) throws Exception;
	List<SchoolDto> getAdjSchoolList(String curLat, String curLng) throws Exception;
}
