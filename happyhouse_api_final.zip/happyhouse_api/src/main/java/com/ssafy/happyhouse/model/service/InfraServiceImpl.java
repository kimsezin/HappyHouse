package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.SchoolDto;
import com.ssafy.happyhouse.model.StoreDto;
import com.ssafy.happyhouse.model.mapper.InfraMapper;

@Service
public class InfraServiceImpl implements InfraService {

	@Autowired
	private InfraMapper infraMapper;
	
	@Override
	public List<StoreDto> getStoreList(String dongCode) throws Exception {
		return infraMapper.getStoreList(dongCode);
	}

	@Override
	public List<StoreDto> getAdjStoreList(String address, String curLat, String curLng) throws Exception {
		return infraMapper.getAdjStoreList(address, curLat, curLng);
	}

	@Override
	public List<SchoolDto> getAdjSchoolList(String curLat, String curLng) throws Exception {
		return infraMapper.getAdjSchoolList(curLat, curLng);
	}

}
