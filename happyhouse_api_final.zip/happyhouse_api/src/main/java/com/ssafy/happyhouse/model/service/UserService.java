package com.ssafy.happyhouse.model.service;

import java.util.Map;

import com.ssafy.happyhouse.model.UserDto;

public interface UserService {

	int idCheck(String userId) throws Exception;
	int registerUser(UserDto userDto) throws Exception;
	UserDto getUser(String userId) throws Exception;
	String findPassword(String userId, String email) throws Exception;
	int deleteUser(String userId) throws Exception;
	UserDto login(UserDto userDto) throws Exception;
	void saveRefreshToken(String userId, String refreshToken) throws Exception;
	UserDto userInfo(String userId) throws Exception;
	String getRefreshToken(String userid) throws Exception;
	void deleRefreshToken(String userid) throws Exception;
	Integer updateDesc(UserDto userDto);
	
}
